.. rst-class:: phpdoctorst

.. role:: php(code)
	:language: php


.. _namespace-AeonDigital-SimpleType-Abstracts:

Abstracts
=========

\AeonDigital\SimpleType\Abstracts


Classes
-------

.. toctree::
	:maxdepth: 6
	
	aBasic <aBasic>
	aFloat <aFloat>
	aInt <aInt>


