.. rst-class:: phpdoctorst

.. role:: php(code)
	:language: php


.. _namespace-AeonDigital-SimpleType:

SimpleType
==========

\AeonDigital\SimpleType


Namespaces
----------

.. toctree::
	:maxdepth: 6
	
	Abstracts <Abstracts/index>


Classes
-------

.. toctree::
	:maxdepth: 6
	
	stBool <stBool>
	stByte <stByte>
	stDateTime <stDateTime>
	stDouble <stDouble>
	stFloat <stFloat>
	stInt <stInt>
	stLong <stLong>
	stReal <stReal>
	stShort <stShort>
	stString <stString>


