.. rst-class:: phpdoctorst

.. role:: php(code)
	:language: php


.. _namespace-AeonDigital-Traits:

Traits
======

\AeonDigital\Traits


Traits
------

.. toctree::
	:maxdepth: 6
	
	HTTPRawStatusCode <HTTPRawStatusCode>
	MimeTypeData <MimeTypeData>
	ParseQualityHeaders <ParseQualityHeaders>


