.. rst-class:: phpdoctorst

.. role:: php(code)
	:language: php


HTTPRawStatusCode
=================


.. php:namespace:: AeonDigital\Traits

.. php:trait:: HTTPRawStatusCode


	.. rst-class:: phpdoc-description
	
		| Coleção de códigos de status ``HTTP`` e suas respectivas **reason phrases**.
		
	

Properties
----------

