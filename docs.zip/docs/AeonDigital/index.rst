.. rst-class:: phpdoctorst

.. role:: php(code)
	:language: php


.. _namespace-AeonDigital:

AeonDigital
===========

\AeonDigital


Namespaces
----------

.. toctree::
	:maxdepth: 6
	
	Collection <Collection/index>
	SimpleType <SimpleType/index>
	Tools <Tools/index>
	Traits <Traits/index>


Classes
-------

.. toctree::
	:maxdepth: 6
	
	Realtype <Realtype>
	Tools <Tools>


