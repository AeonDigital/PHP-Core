=======
Números
=======

.. toctree::
    :maxdepth: 6

    ../global_functions/numeric_decimal_part
    ../global_functions/numeric_integer_part
    ../global_functions/numeric_is_even
    ../global_functions/numeric_is_odd
    ../global_functions/numeric_mod
