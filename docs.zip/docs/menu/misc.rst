====
Misc
====

.. toctree::
    :maxdepth: 6

    ../global_functions/html_print
    ../global_functions/object_clone
    ../global_functions/object_convert_values_to_html_entities
    ../global_functions/redirect
    ../global_functions/to_system_path
    ../global_functions/var_initi_set
    ../global_functions/var_is_defined
