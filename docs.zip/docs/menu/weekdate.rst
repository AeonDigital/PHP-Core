========
WeekDate
========

.. toctree::
    :maxdepth: 6

    ../global_functions/weekdate_count_weeks
    ../global_functions/weekdate_get_first_week
    ../global_functions/weekdate_get_last_week
    ../global_functions/weekdate_to_array
    ../global_functions/weekdate_to_datetime
