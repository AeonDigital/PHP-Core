=======
Strings
=======

.. toctree::
    :maxdepth: 6

    ../global_functions/mb_str_contains
    ../global_functions/mb_str_ends_with
    ../global_functions/mb_str_insert
    ../global_functions/mb_str_last_pos
    ../global_functions/mb_str_limit_chars
    ../global_functions/mb_str_limit_words
    ../global_functions/mb_str_pos_all
    ../global_functions/mb_str_preserve_chars
    ../global_functions/mb_str_remove
    ../global_functions/mb_str_remove_chars
    ../global_functions/mb_str_remove_glyphs
    ../global_functions/mb_str_replace_once
    ../global_functions/mb_str_split
    ../global_functions/mb_str_starts_with
    ../global_functions/mb_str_uc_first
    ../global_functions/mb_str_uc_names
    ../global_functions/mb_str_uc_names_ptbr
    ../global_functions/mb_str_uc_words
    ../global_functions/mb_substr_replace
