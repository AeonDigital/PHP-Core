=====================
Diretórios e Arquivos
=====================

.. toctree::
    :maxdepth: 6

    ../global_functions/dir_chmod_r
    ../global_functions/dir_convert_to_utf8
    ../global_functions/dir_copy
    ../global_functions/dir_deltree
    ../global_functions/dir_scan_w
    ../global_functions/file_convert_to_utf8
