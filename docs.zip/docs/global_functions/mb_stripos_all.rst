==============
mb_stripos_all
==============


.. php:function:: mb_stripos_all($haystack, $needle)

    .. rst-class:: phpdoc-description

        | Encontra todas as ocorrências de uma ``string`` sem diferenciar maiúsculas e minúsculas e
        | retorna um ``array`` com as respectivas posições.


    :param string $string: ``String`` original.
    :param int $split_length: Tamanho máximo de cada parte da ``string``.

    :returns: ‹ false|array ›|br|
        Retornará ``false`` caso nenhuma ocorrência seja encontrada ou um ``array``
        contendo a posição de cada ocorrência fr ``$needle`` encontrada.
