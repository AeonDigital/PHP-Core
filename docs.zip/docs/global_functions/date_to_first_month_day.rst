==============
date_to_first_month_day
==============


.. php:function:: date_to_first_month_day(\DateTime $date)

    .. rst-class:: phpdoc-description

        | Retorna um objeto ``DateTime`` setado para o primeiro dia do mês. Hora minuto e segundo
        | serão definidos como **00:00:00**.


    :param \DateTime $date: Data original.

    :returns: ‹ \DateTime ›|br|
