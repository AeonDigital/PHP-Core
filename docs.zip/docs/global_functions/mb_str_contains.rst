===============
mb_str_contains
===============


.. php:function:: mb_str_contains($str, $search)

    .. rst-class:: phpdoc-description

        | Indica se o valor de entrada possui ``$search`` em alguma posição.


    :param string $str: Valor de entrada.
    :param string $search: Valor a ser procurado.

    :returns: ‹ bool ›|br|
