===========
dir_chmod_r
===========


.. php:function:: dir_chmod_r($absoluteSystemPathToDir, $permissions)

    .. rst-class:: phpdoc-description

        | Efetua alteração nas permissões de um diretório e em todos seus itens filhos.


    :param string $absoluteSystemPathToDir: Diretório que terá suas alterações alteradas.
    :param int $permissions: As permissões que serão setadas.

    :returns: ‹ bool ›|br|
        Retornará ``true`` se TODOS os itens alvo tiverem suas permissões alteradas.
