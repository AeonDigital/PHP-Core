================
str_replace_once
================


.. php:function:: str_replace_once($search, $replace, $subject)

    .. rst-class:: phpdoc-description

        | Substitui apenas a primeira ocorrencia de ``$search`` em ``$subject`` pelo valor
        | correspondente em ``$replace``.


    :param ?string|array $search: Valor que será substituido na ``string``.
    :param ?string|array $replace: Valor que será adicionado no lugar de ``$search``.
    :param string $subject: Valor original que será substituído.

    :returns: ‹ string ›|br|
        Nova ``string`` modificada.
