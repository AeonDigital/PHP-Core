===========
dir_deltree
===========


.. php:function:: dir_deltree($absoluteSystemPathToDir)

    .. rst-class:: phpdoc-description

        | Remove um diretório e todo seu conteúdo.


    :param string $absoluteSystemPathToDir: Diretório que será excluido.

    :returns: ‹ bool ›|br|
        Retornará ``true`` se o diretório alvo for excluído.
