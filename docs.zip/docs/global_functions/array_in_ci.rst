===========
array_in_ci
===========


.. php:function:: array_in_ci($needle, $haystack)

    .. rst-class:: phpdoc-description

        | Versão ``case-insensitive`` para o método ``in_array()``.


    :param string $needle: Valor que será procurado.
    :param array $haystack: ``Array`` onde o valor será procurado.

    :returns: ‹ bool ›|br|
        Retornará ``true`` se o valor de ``$needle`` for encontrado em um dos valores
        contidos no ``array $haystack``.
