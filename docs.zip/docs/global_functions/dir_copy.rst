========
dir_copy
========


.. php:function:: dir_copy($absoluteSystemPathToDir_source, $absoluteSystemPathToDir_dest, $permissions)

    .. rst-class:: phpdoc-description

        | Copia todo o conteúdo de um diretório para outro local.


    :param string $absoluteSystemPathToDir_source: Caminho para o diretório de conteúdo que será copiado.
    :param string $absoluteSystemPathToDir_dest: Caminho para o diretório de destino.
    :param int $permissions: As permissões que devem ser setadas no novo diretório.

    :returns: ‹ bool ›|br|
        Retornará ``true`` se a cópia do conteúdo ocorrer sem erros.
