==================
mb_str_limit_chars
==================


.. php:function:: mb_str_limit_chars($str, $max, $etc)

    .. rst-class:: phpdoc-description

        | Encontra a última ocorrencia de ``$search`` em ``$str``.


    :param string $str: Valor de entrada.
    :param string $search: Valor que deve ser procurado.
    :param int $start: Posição a partir da qual a pesquisa deve ser feita.

    :returns: ‹ false|int ›|br|
        Retornará ``false`` caso a ``string`` não exista.
