==========
dir_scan_w
==========


.. php:function:: dir_scan_w($absoluteSystemPathToDir)

    .. rst-class:: phpdoc-description

        | Retorna a listagem do conteúdo do diretório alvo já ordenado adequadamente conforme o
        | padrão Windows.


    :param string $absoluteSystemPathToDir: Diretório que será listado.

    :returns: ‹ array ›|br|
        Lista de diretórios e arquivos encontrados no local indicado.
