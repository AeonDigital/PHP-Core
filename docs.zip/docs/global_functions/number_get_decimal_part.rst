=======================
number_get_decimal_part
=======================


.. php:function:: number_get_decimal_part($n, $l)

    .. rst-class:: phpdoc-description

        | Retorna unicamente a parte decimal de um numeral.

        | Por questões internas referentes a forma como os numerais de ponto flutuantes funcionam, a
        | maior precisão possível de ser encontrada é a de números de até 15 dígitos, independente do
        | local onde está o ponto decimal.


    :param string|int|float $n: Valor cuja parte decimal será retornada.
    :param int $l: Tamanho da parte decimal a ser retornada.
        Se não for informado, será usado o valor **2**.

    :returns: ‹ float ›|br|
        Retornará **0.0** (forma ``float`` de 0) para valores que não tenham a parte decimal ou para
        valores passados que não sejam numéricos.
