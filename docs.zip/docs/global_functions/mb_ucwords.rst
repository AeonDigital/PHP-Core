==========
mb_ucwords
==========


.. php:function:: mb_ucwords($string)

    .. rst-class:: phpdoc-description

        | Converte para maiúsculas o primeiro caractere de cada palavra.

        | Este método é equivalente ao ``ucwords()`` porém, suporta ``multi-byte``.


    :param string $string: ``String`` que será alterada.

    :returns: ‹ string ›|br|
        Nova ``string`` modificada.
