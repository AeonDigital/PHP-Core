==============
to_system_path
==============


.. php:function:: to_system_path($systemPath)

    .. rst-class:: phpdoc-description

        | Corrige um caminho para uma pasta ou arquivo interno ajustando os separadores de
        | diretório e eliminando duplicação dos mesmos. Qualquer ``\\`` ou ``/`` no final do caminho
        | será removida.


    :param ?string $systemPath: Caminho que será ajustado.


    :returns: ‹ ?string ›|br|
        Caminho corrigido.
