======================
date_to_last_month_day
======================


.. php:function:: date_to_last_month_day(\DateTime $date)

    .. rst-class:: phpdoc-description

        | Retorna um objeto ``DateTime`` setado para o último dia do mês. Hora minuto e segundo
        | serão definidos como **23:59:59**.


    :param \DateTime $date: Data original.

    :returns: ‹ \DateTime ›|br|
