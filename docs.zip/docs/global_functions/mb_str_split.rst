============
mb_str_split
============


.. php:function:: mb_str_split($string, $string_length)

    .. rst-class:: phpdoc-description

        | Converte uma ``string`` para um ``array``.

        | Este método é equivalente ao ``str_split()`` porém, suporta ``multi-byte``.


    :param string $string: String que será convertida.
    :param int $string_length: Tamanho máximo de cada pedaço.

    :returns: ‹ array ›|br|
        Objeto ``array`` que será retornado contendo cada caracter da ``string``
        original em uma posição.
        Se ``$string_length`` for definido, cada item do ``array`` trará uma parte da
        ``string`` original de tamanho igual ao que foi definido.
