===========
starts_with
===========


.. php:function:: starts_with($haystack, $needle)

    .. rst-class:: phpdoc-description

        | Identifica se a ``string`` passada inicia com a sentença indicada.


    :param string $haystack: ``String`` original.
    :param string $needle: Caracteres iniciais.

    :returns: ‹ bool ›|br|
        Retornará ``true`` se ``$haystack`` é uma ``string`` que inicia com ``$needle``.
