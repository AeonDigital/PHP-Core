==========
print_html
==========


.. php:function:: print_html($obj, $o, $w, $h)

    .. rst-class:: phpdoc-description

        | Imprime na tela o valor de ``$obj`` dentro de uma tag ``<pre>``, facilitando assim a leitura
        | quando necessário o debug.


    :param mixed $obj: Objeto que será **impresso**.
    :param bool $o: Indica se a tag ``<pre>`` deve receber a propriedade css ``overflow:auto``.
    :param string $w: Valor da propriedade css ``width`` para definir a largura do objeto ``<pre>``.
    :param string $h: Valor da propriedade css ``height`` para definir a altura do objeto ``<pre>``.

    :returns: ‹ void ›|br|
