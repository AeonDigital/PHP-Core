===================
clone_simple_object
===================


.. php:function:: clone_simple_object($obj)

    .. rst-class:: phpdoc-description
    
        | Efetua a clonagem de um objeto que pode ser um ``Array Associativo``, uma instância ``\StdClass`` 
        | ou um objeto ``\DateTime``.
        
    
    :param mixed $obj: Objeto que será clonado.

    :returns: ‹ mixed ›|br|
