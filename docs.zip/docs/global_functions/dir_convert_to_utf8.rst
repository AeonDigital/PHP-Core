===================
dir_convert_to_utf8
===================


.. php:function:: dir_convert_to_utf8($absoluteSystemPaths, $validExtensions)

    .. rst-class:: phpdoc-description

        | Converte todos os arquivos alvo para o encode **UTF-8**.

        | Se algum diretório for alvo desta ação, todos os seus arquivos filhos (incluindo subdiretórios)
        | serão também convertidos.
        | Ocorrendo qualquer falha durante o processamento das conversões, o processamento parará imediatamente.


    :param string[] $absoluteSystemPaths: Caminhos para os recursos que serão convertidos.
        Podem ser apontados diretórios ou arquivos.
    :param string[] $validExtensions: Coleção de extenções válidas para executar a conversão.

    :returns: ‹ bool ›|br|
        Retornará ``true`` se TODOS os recursos indicados em ``$absoluteSystemPaths``
        existirem e forem corretamente convertidos.
