=======================
number_get_integer_part
=======================


.. php:function:: number_get_integer_part($n)

    .. rst-class:: phpdoc-description

        | Retorna unicamente a parte inteira de um numeral.


    :param string|int|float $n: Valor cuja parte inteira será retornada.

    :returns: ‹ int ›|br|
        Retornará **0** para valores que não sejam numéricos.
        Podem ser utilizados valores com até 14 digitos na parte inteira.
