==============================
convert_object_to_htmlentities
==============================


.. php:function:: convert_object_to_htmlentities($o)

    .. rst-class:: phpdoc-description

        | Converte todo conteúdo de um ``Array Associativo`` ou objeto ``\StdClass`` em um valor do tipo
        | ``string`` que pode ser apresentado normalmente em um documento HTML.


    :param mixed $o: Objeto original, que será convertido.

    :returns: ‹ bool ›|br|
        Retornará o mesmo tipo de objeto inicialmente passado em ``$o``, mas com todos
        seus valores convertidos para ``strings`` representáveis em um documento HTML.
