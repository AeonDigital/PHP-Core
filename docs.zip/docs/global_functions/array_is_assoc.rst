==============
array_is_assoc
==============


.. php:function:: array_is_assoc($o)

    .. rst-class:: phpdoc-description

        | Verifica se o objeto passado é um ``Array Associativo``.


    :param mixed $o: Objeto que será testado.

    :returns: ‹ bool ›|br|
        Retornará ``true`` se ``$o`` for mesmo um ``Array Associativo``.
        Um ``array`` vazio retornará ``false``.
