=========
initi_set
=========


.. php:function:: initi_set($o, $d, $u)

    .. rst-class:: phpdoc-description

        | Se a variável indicada não estiver definida, irá iniciá-la com o valor padrão passado.


    :param mixed $o: Objeto a ser iniciado.
    :param mixed $d: Valor padrão a ser definido.
    :param bool $u: Se ``true`` testa apenas se o valor é ``undefined``.
        Se ``false`` testa usando ``is_defined()``.

    :returns: ‹ void ›|br|
