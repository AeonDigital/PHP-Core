==========
mb_ucnames
==========


.. php:function:: mb_ucnames($string, $ignore)

    .. rst-class:: phpdoc-description

        | Converte para maiúsculas o primeiro caractere de cada parte de uma ``string`` que representa
        | um nome próprio. Todos os demais caracteres da ``string`` passada serão revertidos para
        | minúsculas.


    :param string $string: ``String`` que será alterada.
    :param array $ignore: Se definido, deve ser um ``array de strings`` contendo palavras que devem escapar
        da transformação.

    :returns: ‹ string ›|br|
        Nova ``string`` modificada.
