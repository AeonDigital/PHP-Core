==========
mb_ucfirst
==========


.. php:function:: mb_ucfirst($string)

    .. rst-class:: phpdoc-description

        | Converte para maiúscula o primeiro caractere de uma ``string``.

        | Este método é equivalente ao ``ucfirst()`` porém, suporta ``multi-byte``.


    :param string $string: ``String`` que será alterada.

    :returns: ‹ string ›|br|
        Nova ``string`` modificada.
