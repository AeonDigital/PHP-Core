==========
is_defined
==========


.. php:function:: is_defined($o)

    .. rst-class:: phpdoc-description

        | Verifica se a variável indicada está definida.

        | Uma variável é considerada definida quando NÃO FOR um ``array`` vazio ou um objeto
        | ``\StdClass`` vazio, ou, quando tratar-se de um tipo escalar, for diferente de ``null``,
        | ``undefined`` e ``''``.


    :param mixed $o: Objeto que será testado.
    :param ?string $k: Quando indicado, ``$o`` deve ser um ``array`` ou um objeto ``\StdClass`` e ``$k``
        será cuja existência e valor será verificado.

    :returns: ‹ bool ›|br|
        Retornará ``true`` SE a variável ESTA definida E SE seu valor é diferente de
        ``null``, ``undefined`` e ``''``.
        Objetos do tipo ``array`` e ``\StdClass`` retornarão ``true`` SE não forem vazios
        quando ``$k`` não for definido.
