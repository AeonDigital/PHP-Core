=================
mb_substr_replace
=================


.. php:function:: mb_substr_replace($string, $replacement, $start, $length, $encoding)

    .. rst-class:: phpdoc-description

        | Substitui o texto em uma parte da ``string`` por outro.

        | Este método é equivalente ao ``substr_replace()`` porém, suporta ``multi-byte``.


    :param string $string: ``String`` original.
    :param string $replacement: ``String`` que será adicionada.
    :param int $start: Posição inicial para inserir a nova ``string``.
    :param ?int $length: Tamanho da porção da ``string`` original que será substituída.
    :param ?string $encoding: Quando usado indica que codificação a ``string`` original está usando.

    :returns: ‹ string ›|br|
        Nova ``string`` com o novo valor.
