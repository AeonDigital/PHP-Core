===================
entities_to_unicode
===================


.. php:function:: entities_to_unicode($str)

    .. rst-class:: phpdoc-description

        | Converte todas as entidades HTML, nomeadas ou numéricas em suas versões **UTF-8**.


    :param string $str: ``String`` que será convertida.

    :returns: ‹ string ›|br|
        Nova ``string`` contendo todas entidades HTML convertidas para seus respectivos
        caracteres **UTF-8**.
